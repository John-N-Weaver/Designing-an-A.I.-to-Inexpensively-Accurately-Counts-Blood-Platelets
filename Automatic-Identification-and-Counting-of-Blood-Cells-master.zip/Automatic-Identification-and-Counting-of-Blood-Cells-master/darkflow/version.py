__version__ = '1.0.0'
"""Current version of darkflow."""
